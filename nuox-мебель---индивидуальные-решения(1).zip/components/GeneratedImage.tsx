
import React from 'react';

interface GeneratedImageProps {
  src?: string;
  alt: string;
  className?: string;
  prompt?: string; // Оставляем в пропсах для совместимости, но не используем
}

const GeneratedImage: React.FC<GeneratedImageProps> = ({ src, alt, className }) => {
  return (
    <div className={`relative overflow-hidden group ${className}`}>
      {src ? (
        <img 
          src={src} 
          alt={alt} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
      ) : (
        <div className="w-full h-full bg-gray-100 flex items-center justify-center flex-col p-4 text-center">
          <svg className="w-12 h-12 text-gray-300 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          <p className="text-xs text-gray-400">Изображение не найдено</p>
        </div>
      )}

      {/* Маркер AI контента оставляем только для уже существующих base64 данных, если они есть */}
      {src?.startsWith('data:image') && (
        <div className="absolute bottom-4 left-4 bg-nuox-accent/80 backdrop-blur px-2 py-0.5 rounded text-[8px] font-bold text-white uppercase tracking-tighter pointer-events-none">
          AI Generated
        </div>
      )}
    </div>
  );
};

export default GeneratedImage;

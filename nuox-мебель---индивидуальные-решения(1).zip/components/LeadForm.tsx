
import React from 'react';

interface LeadFormProps {
  title?: string;
  subtitle?: string;
}

const LeadForm: React.FC<LeadFormProps> = ({ 
  title = "Рассчитаем стоимость за 5 минут", 
  subtitle = "Выберите удобный мессенджер для связи. Наш дизайнер пришлет анкету и ответит на все вопросы." 
}) => {
  return (
    <div className="bg-white p-8 md:p-12 rounded-[2.5rem] shadow-2xl border border-gray-100 text-center">
      <h3 className="text-2xl md:text-3xl font-serif font-bold text-gray-900 mb-4">{title}</h3>
      <p className="text-gray-600 mb-10 text-sm md:text-base leading-relaxed max-w-sm mx-auto">{subtitle}</p>
      
      <div className="space-y-4">
        <a 
          href="https://t.me/nuox_mebel" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center justify-center space-x-3 w-full bg-[#229ED9] text-white font-bold py-5 rounded-2xl shadow-lg shadow-blue-500/20 hover:scale-[1.02] transition-all group"
        >
          <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.11.02-1.93 1.23-5.46 3.62-.51.35-.98.53-1.39.51-.46-.01-1.33-.26-1.98-.48-.8-.27-1.43-.41-1.38-.87.03-.24.36-.48.99-.74 3.89-1.69 6.48-2.8 7.78-3.33 3.69-1.52 4.45-1.78 4.95-1.79.11 0 .36.03.52.16.13.11.17.26.18.37 0 .04.01.12 0 .19z"/>
          </svg>
          <span>Написать в Telegram</span>
        </a>

        <a 
          href="https://wa.me/79152197969" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center justify-center space-x-3 w-full bg-[#25D366] text-white font-bold py-5 rounded-2xl shadow-lg shadow-green-500/20 hover:scale-[1.02] transition-all group"
        >
          <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
            <path d="M12.012 2c-5.508 0-9.992 4.484-9.992 9.992 0 1.758.459 3.469 1.333 4.975l-1.353 4.933 5.044-1.323c1.46.797 3.097 1.216 4.768 1.217h.004c5.508 0 9.991-4.484 9.991-9.992 0-2.662-1.037-5.164-2.922-7.049-1.885-1.885-4.387-2.922-7.049-2.922zm5.735 14.034c-.237.669-1.378 1.284-1.908 1.371-.475.078-1.096.143-3.15-.71-2.628-1.091-4.275-3.765-4.406-3.939-.131-.174-1.062-1.412-1.062-2.69 0-1.279.67-1.903.906-2.17.237-.266.521-.333.695-.333s.348.001.501.009c.162.008.38-.061.595.454.214.515.736 1.79.801 1.921.065.131.109.283.022.456-.088.174-.131.283-.262.434-.131.152-.275.339-.392.454-.131.131-.268.274-.115.538.153.263.679 1.119 1.458 1.812.999.889 1.843 1.164 2.106 1.297.263.131.415.109.568-.065.153-.174.654-.761.83-.1.174.174.37.457.831.691.462.234 2.919 1.373 3.007 1.503.088.131.088.239.043.372z"/>
          </svg>
          <span>Написать в WhatsApp</span>
        </a>
      </div>

      <div className="mt-8 pt-8 border-t border-gray-100">
        <p className="text-sm text-gray-400 mb-2">Или позвоните нам напрямую:</p>
        <a href="tel:+79990000000" className="text-xl font-bold text-gray-900 hover:text-nuox-accent transition-colors">
          +7 (915) 219-79-69
        </a>
      </div>

      <p className="mt-6 text-[10px] text-gray-400 leading-tight">
        Нажимая на кнопки, вы переходите в официальные бизнес-аккаунты NUOX мебель. Ваши данные защищены политикой конфиденциальности.
      </p>
    </div>
  );
};

export default LeadForm;

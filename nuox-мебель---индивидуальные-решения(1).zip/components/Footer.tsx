
import React from 'react';

interface FooterProps {
  onNavigate: (path: string) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const handleNav = (e: React.MouseEvent, path: string) => {
    e.preventDefault();
    onNavigate(path);
  };

  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-1">
            <h2 className="text-2xl font-bold mb-6">NUOX <span className="text-nuox-accent">мебель</span></h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              Создаем уют и комфорт в вашем доме с 2015 года. Собственное производство и индивидуальный подход к каждому клиенту.
            </p>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-6">Продукция</h3>
            <ul className="space-y-4 text-sm text-gray-400">
              <li><button onClick={(e) => handleNav(e, '/catalog')} className="hover:text-white transition-colors">Кухни</button></li>
              <li><button onClick={(e) => handleNav(e, '/catalog')} className="hover:text-white transition-colors">Спальни</button></li>
              <li><button onClick={(e) => handleNav(e, '/catalog')} className="hover:text-white transition-colors">Детские</button></li>
              <li><button onClick={(e) => handleNav(e, '/catalog')} className="hover:text-white transition-colors">Шкафы-купе</button></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-6">Компания</h3>
            <ul className="space-y-4 text-sm text-gray-400">
              <li><button onClick={(e) => handleNav(e, '/about')} className="hover:text-white transition-colors">О нас</button></li>
              <li><button onClick={(e) => handleNav(e, '/materials')} className="hover:text-white transition-colors">Материалы</button></li>
              <li><button onClick={(e) => handleNav(e, '/catalog')} className="hover:text-white transition-colors">Этапы работы</button></li>
              <li><button onClick={(e) => handleNav(e, '/contacts')} className="hover:text-white transition-colors">Контакты</button></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-6">Контакты</h3>
            <ul className="space-y-4 text-sm text-gray-400">
              <li>+7 (915) 219-79-69</li>
              <li>info@nuox-mebel.ru</li>
              <li>г. Москва, ул. Примерная, 10</li>
              <li className="flex space-x-4 pt-2">
                <a href="#" className="hover:text-nuox-accent transition-colors">TG</a>
                <a href="#" className="hover:text-nuox-accent transition-colors">WA</a>
                <a href="#" className="hover:text-nuox-accent transition-colors">VK</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500">
          <p>© 2024 NUOX мебель. Все права защищены.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-white">Политика конфиденциальности</a>
            <a href="#" className="hover:text-white">Публичная оферта</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

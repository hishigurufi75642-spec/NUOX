
import React, { useState } from 'react';

interface NavbarProps {
  onNavigate: (path: string) => void;
  currentPath: string;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, currentPath }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { name: 'Главная', path: '/' },
    { name: 'Каталог', path: '/catalog' },
    { name: 'О компании', path: '/about' },
    { name: 'Материалы', path: '/materials' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <button 
              onClick={() => onNavigate('/')}
              className="flex-shrink-0 flex items-center"
            >
              <span className="text-2xl font-bold tracking-tighter text-gray-900">
                NUOX <span className="text-nuox-accent">мебель</span>
              </span>
            </button>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.path}
                onClick={() => onNavigate(item.path)}
                className={`${
                  currentPath === item.path
                    ? 'text-nuox-accent border-b-2 border-nuox-accent'
                    : 'text-gray-600 hover:text-nuox-accent'
                } px-1 py-2 text-sm font-medium transition-all`}
              >
                {item.name}
              </button>
            ))}
            <button 
              onClick={() => onNavigate('/contacts')}
              className="bg-nuox-accent text-white px-6 py-2 rounded-full text-sm font-medium hover:bg-opacity-90 transition-all shadow-sm"
            >
              Рассчитать стоимость
            </button>
          </div>

          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {isOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-b border-gray-100">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navItems.map((item) => (
              <button
                key={item.path}
                onClick={() => {
                  onNavigate(item.path);
                  setIsOpen(false);
                }}
                className={`${
                  currentPath === item.path
                    ? 'bg-nuox-accent/10 text-nuox-accent'
                    : 'text-gray-600 hover:bg-gray-50'
                } block w-full text-left px-3 py-2 rounded-md text-base font-medium`}
              >
                {item.name}
              </button>
            ))}
            <button
              onClick={() => {
                onNavigate('/contacts');
                setIsOpen(false);
              }}
              className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-nuox-accent bg-nuox-accent/5"
            >
              Рассчитать стоимость
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;

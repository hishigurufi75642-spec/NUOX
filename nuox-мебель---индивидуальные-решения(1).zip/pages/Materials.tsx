
import React from 'react';
import GeneratedImage from '../components/GeneratedImage';

const Materials: React.FC = () => {
  const materialsList = [
    { 
      title: 'ЛДСП', 
      desc: 'Egger, Kronospan, Lamarty. Широкий выбор текстур и высокая износостойкость.', 
      icon: '📁' 
    },
    { 
      title: 'Фурнитура', 
      desc: 'Boyard, Firmax, GTV, Blum. Качественные механизмы для долговечной работы.', 
      icon: '⚙️' 
    },
    { 
      title: 'МДФ пленка ПВХ', 
      desc: 'Практичное решение с огромным выбором цветов и древесных текстур.', 
      icon: '🎞️' 
    },
    { 
      title: 'МДФ эмаль', 
      desc: 'Идеальное покрытие с глубоким цветом и возможностью реставрации.', 
      icon: '🎨' 
    },
    { 
      title: 'МДФ фрезеровка', 
      desc: 'Реализуем фрезеровку любой сложности: от классики до современных паттернов.', 
      icon: '📐' 
    },
  ];

  return (
    <div className="pb-24">
      <section className="bg-nuox-accent text-white py-24 mb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-serif font-bold mb-6">Качество в деталях</h1>
          <p className="text-lg opacity-90 max-w-2xl mx-auto">Мы используем только проверенные материалы от лидеров рынка для вашей мебели.</p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 mb-32">
          {materialsList.map((m, idx) => (
            <div key={idx} className="p-10 bg-white rounded-3xl border border-gray-100 shadow-sm hover:shadow-xl transition-all">
              <div className="text-4xl mb-6">{m.icon}</div>
              <h3 className="text-2xl font-bold mb-4">{m.title}</h3>
              <p className="text-gray-500 leading-relaxed">{m.desc}</p>
            </div>
          ))}
        </div>

        <section className="flex flex-col lg:flex-row gap-16 items-center mb-32">
          <div className="lg:w-1/2">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-8">Технологичность и эстетика</h2>
            <p className="text-gray-600 mb-6 leading-relaxed">
              Мы уделяем особое внимание внутреннему наполнению. Мебель NUOX — это не только красивый фасад, но и безупречная работа каждого механизма и продуманная система хранения для вашего удобства.
            </p>
            <ul className="space-y-4">
              <li className="flex items-center space-x-3">
                <div className="w-5 h-5 bg-green-100 text-green-600 rounded-full flex items-center justify-center">✓</div>
                <span className="text-sm font-medium">Бесшумные системы выдвижения и доводчики</span>
              </li>
              <li className="flex items-center space-x-3">
                <div className="w-5 h-5 bg-green-100 text-green-600 rounded-full flex items-center justify-center">✓</div>
                <span className="text-sm font-medium">Эргономичные системы хранения (pantry units, magic corners)</span>
              </li>
              <li className="flex items-center space-x-3">
                <div className="w-5 h-5 bg-green-100 text-green-600 rounded-full flex items-center justify-center">✓</div>
                <span className="text-sm font-medium">Огромный каталог образцов фасадов и столешниц</span>
              </li>
            </ul>
          </div>
          <div className="lg:w-1/2 grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <GeneratedImage 
                className="rounded-2xl h-56 w-full" 
                alt="Furniture Material Samples"
                prompt="A professional studio display of luxury furniture material samples: a palette of wood swatches, stone countertops, and matte enamel color chips, minimalist layout"
              />
              <GeneratedImage 
                className="rounded-2xl h-64 w-full" 
                alt="Internal Storage System"
                prompt="Close-up of a modern internal kitchen storage system, a pull-out chrome pantry unit or magic corner drawer organized with high-end accessories"
              />
            </div>
            <div className="space-y-4 pt-12">
              <GeneratedImage 
                className="rounded-2xl h-64 w-full" 
                alt="Cabinet Mechanism Close-up"
                prompt="Macro photography of a premium stainless steel cabinet hinge or lift-up mechanism (Blum style), focus on the technical precision and soft-close hardware"
              />
              <GeneratedImage 
                className="rounded-2xl h-56 w-full" 
                alt="Drawer Runners Detail"
                prompt="Close-up of hidden soft-close drawer runners and high-quality internal wooden drawer construction, emphasis on smooth movement and durability"
              />
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Materials;


import React from 'react';
import LeadForm from '../components/LeadForm';

const Contacts: React.FC = () => {
  return (
    <div className="pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24">
          <div>
            <h1 className="text-5xl md:text-6xl font-serif font-bold mb-12">Свяжитесь <br /> с нами</h1>
            
            <div className="space-y-12 mb-16">
              <div>
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Наш адрес</h3>
                <p className="text-xl font-medium text-gray-900">г. Москва, ул. Примерная, 10, <br /> шоурум №5</p>
              </div>
              
              <div>
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Телефоны</h3>
                <p className="text-xl font-medium text-gray-900">+7 (915) 219-79-69</p>
                <p className="text-sm text-gray-500">Ежедневно с 10:00 до 22:00</p>
              </div>

              <div>
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Email</h3>
                <p className="text-xl font-medium text-gray-900">mebelgusmanov@gmail.com</p>
              </div>

              <div>
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Соцсети</h3>
                <div className="flex space-x-6 mt-4">
                  <a href="#" className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 hover:bg-nuox-accent hover:text-white transition-all">TG</a>
                  <a href="#" className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 hover:bg-nuox-accent hover:text-white transition-all">WA</a>
                  <a href="#" className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 hover:bg-nuox-accent hover:text-white transition-all">VK</a>
                </div>
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="w-full h-80 bg-gray-100 rounded-3xl relative overflow-hidden shadow-inner border border-gray-100">
               <div className="absolute inset-0 flex items-center justify-center text-gray-400 font-medium z-10 bg-white/40 backdrop-blur-[2px]">
                  Интерактивная карта скоро появится
               </div>
               <img src="https://images.unsplash.com/photo-1582037928867-17381121d7c5?auto=format&fit=crop&q=80&w=800" alt="Showroom exterior" className="w-full h-full object-cover opacity-60 grayscale" />
            </div>
          </div>

          <div className="bg-white p-2 rounded-[2.5rem] shadow-2xl">
            <LeadForm 
               title="Обсудим ваш проект?" 
               subtitle="Заполните форму, и мы подготовим для вас персональное предложение" 
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contacts;

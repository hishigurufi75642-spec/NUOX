
import React from 'react';
import { CATEGORIES, PROJECTS, STEPS, ADVANTAGES, REVIEWS } from '../constants';
import LeadForm from '../components/LeadForm';
import GeneratedImage from '../components/GeneratedImage';

interface HomeProps {
  onNavigate: (path: string) => void;
}

const Home: React.FC<HomeProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-24 pb-24">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <GeneratedImage 
            src="https://images.unsplash.com/photo-1620626011761-9963d7b59675?auto=format&fit=crop&q=80&w=1920"
            alt="Interior Hero" 
            className="w-full h-full brightness-75"
            prompt="Ultra-luxury modern minimalist kitchen, custom sage green matte cabinetry matching hex a3b18a, light oak wood accents, premium off-white marble textures. Detailed kitchen filling: sleek built-in black glass oven, a minimalist designer kettle on the counter, organic ceramic bowls, a small vase with fresh green eucalyptus, indirect warm LED lighting, soft natural morning light through a large window, architectural digest style, clean lines, high-end craftsmanship"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-2xl text-white">
            <h1 className="text-5xl md:text-7xl font-serif font-bold leading-tight mb-6">
              Мебель, созданная <br />
              <span className="text-nuox-accent italic">под ваш дом</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-lg leading-relaxed">
              Индивидуальные решения из экологичных материалов. От проекта до монтажа за 21 день.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <button 
                onClick={() => onNavigate('/catalog')}
                className="bg-nuox-accent text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-opacity-90 transition-all shadow-lg"
              >
                Смотреть каталог
              </button>
              <button 
                onClick={() => {
                  const el = document.getElementById('contact-form');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="bg-white/10 backdrop-blur-md border border-white/30 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-white/20 transition-all"
              >
                Рассчитать стоимость
              </button>
            </div>
          </div>
        </div>
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce hidden md:block">
           <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" /></svg>
        </div>
      </section>

      {/* Advantages */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {ADVANTAGES.map((adv, idx) => (
            <div key={idx} className="p-8 bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-nuox-accent/10 text-nuox-accent rounded-xl flex items-center justify-center mb-6">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{adv.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed">{adv.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-serif font-bold mb-4">Наши направления</h2>
          <p className="text-gray-500 max-w-xl mx-auto">Каждая деталь продумана для вашего комфорта</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {CATEGORIES.map((cat) => (
            <div 
              key={cat.id} 
              className="group relative h-96 rounded-3xl overflow-hidden cursor-pointer bg-gray-50"
              onClick={() => onNavigate('/catalog')}
            >
              <GeneratedImage 
                src={cat.image} 
                alt={cat.title} 
                className="w-full h-full"
                prompt={`${cat.title} furniture in a stylish modern interior`}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-8 text-white pointer-events-none">
                <h3 className="text-2xl font-bold mb-2">{cat.title}</h3>
                <p className="text-sm text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  {cat.description}
                </p>
                <div className="mt-4 flex items-center text-nuox-accent font-medium text-sm">
                  Подробнее 
                  <svg className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Steps Section */}
      <section className="bg-gray-50 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2">
              <h2 className="text-3xl md:text-5xl font-serif font-bold mb-8">Как мы работаем</h2>
              <div className="space-y-8">
                {STEPS.map((step) => (
                  <div key={step.number} className="flex space-x-6">
                    <div className="flex-shrink-0 w-12 h-12 rounded-full bg-white text-nuox-accent font-bold flex items-center justify-center shadow-sm border border-gray-100">
                      {step.number}
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">{step.title}</h4>
                      <p className="text-sm text-gray-500 leading-relaxed">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="lg:w-1/2 relative">
              <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl">
                <img src="https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=800" alt="Production" className="w-full h-full object-cover" />
              </div>
              <div className="absolute -bottom-10 -right-10 bg-nuox-accent p-12 rounded-3xl text-white hidden md:block">
                <p className="text-4xl font-bold mb-1">1500+</p>
                <p className="text-sm opacity-80">Реализованных проектов</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-16">
          <div>
            <h2 className="text-3xl md:text-5xl font-serif font-bold mb-4">Наши проекты</h2>
            <p className="text-gray-500">Примеры работ, которыми мы гордимся</p>
          </div>
          <button onClick={() => onNavigate('/catalog')} className="text-nuox-accent font-bold hover:underline hidden sm:block">Все проекты</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {PROJECTS.map((project) => (
            <div key={project.id} className="bg-white rounded-3xl overflow-hidden border border-gray-100 hover:shadow-xl transition-all group">
              <div className="h-64">
                <GeneratedImage 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full"
                  prompt={`${project.title}, ${project.category} furniture set`}
                />
              </div>
              <div className="p-8">
                <span className="text-[10px] uppercase font-bold text-nuox-accent tracking-widest mb-2 block">{project.category}</span>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{project.title}</h3>
                <p className="text-sm text-gray-500 mb-6 line-clamp-2">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.materials.map(m => (
                    <span key={m} className="px-3 py-1 bg-gray-50 text-gray-400 text-[10px] rounded-full">{m}</span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Reviews */}
      <section className="bg-gray-900 text-white py-24 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-5xl font-serif font-bold mb-16 text-center">Что говорят наши клиенты</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {REVIEWS.map((review) => (
              <div key={review.id} className="bg-white/5 backdrop-blur-sm p-10 rounded-3xl border border-white/10">
                <div className="flex items-center space-x-4 mb-6">
                  <img src={review.avatar} alt={review.author} className="w-14 h-14 rounded-full" />
                  <div>
                    <h4 className="font-bold">{review.author}</h4>
                    <p className="text-xs text-gray-400">{review.date}</p>
                  </div>
                  <div className="ml-auto flex text-yellow-500">
                    {[...Array(review.rating)].map((_, i) => (
                      <svg key={i} className="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                    ))}
                  </div>
                </div>
                <p className="text-gray-300 italic leading-relaxed">"{review.text}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact-form" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-nuox-accent/5 rounded-[3rem] p-8 md:p-16 flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2">
            <h2 className="text-3xl md:text-5xl font-serif font-bold mb-6 text-gray-900">Готовы создать <br /> мебель вашей мечты?</h2>
            <p className="text-gray-600 mb-8 leading-relaxed">
              Оставьте заявку на бесплатную консультацию. Наши специалисты помогут определиться со стилем, материалами и рассчитают предварительную стоимость.
            </p>
            <div className="flex items-center space-x-6">
              <div className="flex -space-x-4">
                {[1, 2, 3, 4].map(i => (
                  <img key={i} src={`https://i.pravatar.cc/100?u=${i}`} className="w-12 h-12 rounded-full border-2 border-white" />
                ))}
              </div>
              <p className="text-sm text-gray-500 font-medium">Более 1500 семей <br /> уже выбрали нас</p>
            </div>
          </div>
          <div className="lg:w-1/2 w-full">
            <LeadForm />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;

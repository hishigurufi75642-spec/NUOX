
import React, { useState } from 'react';
import { CATEGORIES, PROJECTS } from '../constants';
import LeadForm from '../components/LeadForm';
import GeneratedImage from '../components/GeneratedImage';

interface CatalogProps {
  onNavigate?: (path: string) => void;
}

const Catalog: React.FC<CatalogProps> = ({ onNavigate }) => {
  const [activeCategory, setActiveCategory] = useState('all');

  const filteredProjects = activeCategory === 'all' 
    ? PROJECTS 
    : PROJECTS.filter(p => p.category === CATEGORIES.find(c => c.id === activeCategory)?.title);

  // Вспомогательная функция для формирования точного промпта
  const getProjectPrompt = (project: any) => {
    let basePrompt = `High-end bespoke furniture: ${project.title}, ${project.category}. `;
    
    // Добавляем специфичные детали в зависимости от названия
    if (project.title.includes('Gola')) basePrompt += "Minimalist kitchen with Gola profile handleless system, clean horizontal lines. ";
    if (project.title.includes('фрезеровкой')) basePrompt += "Detailed decorative milling pattern on cabinet doors, architectural shadows. ";
    if (project.title.includes('металлической')) basePrompt += "Black aluminum slim frame glass doors, grey tinted glass, internal LED shelving light. ";
    if (project.title.includes('неоклассика')) basePrompt += "Neoclassic style, thin frame cabinetry, elegant proportions. ";
    if (project.title.includes('Детские')) basePrompt += "Calm pastel colors, soft matte finish, organized shelving. ";
    if (project.title.includes('купе')) basePrompt += "Sliding wardrobe system, floor to ceiling, premium profiles. ";
    if (project.title.includes('консоль')) basePrompt += "Wall-mounted floating TV unit, modern living room setting. ";
    
    return basePrompt + "Professional interior photography, architectural lighting, luxury materials.";
  };

  return (
    <div className="pb-24">
      {/* Header */}
      <section className="bg-gray-100 py-24 mb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-serif font-bold mb-6">Каталог решений</h1>
          <p className="text-gray-500 max-w-2xl mx-auto">
            Исследуйте наши возможности. Мы создаем мебель любой сложности, учитывая каждую деталь вашего ТЗ.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-4 mb-16">
          <button 
            onClick={() => setActiveCategory('all')}
            className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
              activeCategory === 'all' ? 'bg-nuox-accent text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-nuox-accent'
            }`}
          >
            Все проекты
          </button>
          {CATEGORIES.map(cat => (
            <button 
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                activeCategory === cat.id ? 'bg-nuox-accent text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-nuox-accent'
              }`}
            >
              {cat.title}
            </button>
          ))}
        </div>

        {/* Project Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 mb-24">
          {filteredProjects.map(project => (
            <div key={project.id} className="group flex flex-col h-full">
              <div className="aspect-[4/3] rounded-3xl overflow-hidden mb-6 shadow-sm group-hover:shadow-xl transition-all bg-gray-50 flex-shrink-0">
                <GeneratedImage 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full"
                  prompt={getProjectPrompt(project)}
                />
              </div>
              <div className="flex-grow">
                <span className="text-[10px] uppercase font-bold text-nuox-accent tracking-widest mb-2 block">{project.category}</span>
                <h3 className="text-xl font-bold mb-3 group-hover:text-nuox-accent transition-colors">{project.title}</h3>
                <p className="text-sm text-gray-500 mb-4 line-clamp-3">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.materials.map(m => (
                    <span key={m} className="px-2 py-1 bg-gray-50 text-gray-400 text-[10px] rounded-md">{m}</span>
                  ))}
                </div>
              </div>
              <button 
                onClick={() => onNavigate?.('/contacts')}
                className="text-sm font-bold border-b-2 border-transparent hover:border-nuox-accent transition-all pb-1 self-start"
              >
                Рассчитать стоимость
              </button>
            </div>
          ))}
        </div>

        {/* Banner */}
        <div className="bg-gray-900 rounded-[3rem] p-12 md:p-20 text-white relative overflow-hidden">
          <div className="relative z-10 max-w-2xl">
            <h2 className="text-3xl md:text-5xl font-serif font-bold mb-8">Индивидуальный проект</h2>
            <p className="text-gray-400 mb-10 text-lg leading-relaxed">
              Мы специализируемся на нестандартных задачах. Наши дизайнеры разработают проект с нуля, учитывая каждый сантиметр вашего пространства и выбранные материалы.
            </p>
            <button 
              onClick={() => onNavigate?.('/contacts')}
              className="bg-nuox-accent text-white px-10 py-4 rounded-full font-bold hover:scale-105 transition-transform shadow-lg shadow-nuox-accent/20"
            >
              Бесплатная консультация
            </button>
          </div>
          <div className="absolute top-0 right-0 w-1/3 h-full opacity-30 hidden lg:block">
            <GeneratedImage 
              src="https://picsum.photos/seed/catalog-cta/600/800" 
              alt="Design" 
              className="w-full h-full"
              prompt="Luxury bespoke furniture design sketch and materials, architect desk"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Catalog;

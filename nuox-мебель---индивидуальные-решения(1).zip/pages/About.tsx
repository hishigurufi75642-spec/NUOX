
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="pb-24">
      {/* Hero */}
      <section className="relative h-[60vh] flex items-center mb-24 overflow-hidden">
        <img src="https://images.unsplash.com/photo-1554995207-c18c203602cb?auto=format&fit=crop&q=80&w=1920" alt="About" className="absolute inset-0 w-full h-full object-cover brightness-50" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <h1 className="text-5xl md:text-7xl font-serif font-bold mb-6">Создаем уют <br /> с душой</h1>
          <p className="text-xl text-gray-300 max-w-2xl">NUOX мебель — это команда профессионалов, влюбленных в свое дело.</p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center mb-32">
          <div>
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-8 text-gray-900">Наша история</h2>
            <p className="text-gray-600 mb-6 leading-relaxed">
              История NUOX началась 10 лет назад с небольшой мастерской. Сегодня мы — это современное высокотехнологичное производство в Москве, оснащенное европейским оборудованием.
            </p>
            <p className="text-gray-600 mb-6 leading-relaxed">
              Мы верим, что мебель должна быть не просто функциональной, но и экологичной. Поэтому мы тщательно отбираем поставщиков материалов и фурнитуры, отдавая предпочтение проверенным брендам.
            </p>
            <div className="grid grid-cols-2 gap-8 mt-12">
              <div>
                <p className="text-4xl font-bold text-nuox-accent mb-1">10+</p>
                <p className="text-sm text-gray-500">Лет на рынке</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-nuox-accent mb-1">2000+</p>
                <p className="text-sm text-gray-500">Довольных клиентов</p>
              </div>
            </div>
          </div>
          <div className="relative">
            <img src="https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&q=80&w=800" alt="Factory" className="rounded-3xl shadow-2xl" />
            <div className="absolute -bottom-10 -left-10 bg-white p-8 rounded-2xl shadow-xl hidden md:block border border-gray-100">
              <p className="text-gray-900 font-bold italic">"Наша миссия — сделать премиальный дизайн доступным и экологичным"</p>
            </div>
          </div>
        </div>

        <section className="bg-nuox-accent/5 rounded-[3rem] p-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-16 text-center">Наши ценности</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
                <svg className="w-8 h-8 text-nuox-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
              </div>
              <h3 className="text-xl font-bold mb-4">Надежность</h3>
              <p className="text-sm text-gray-500">Гарантируем качество материалов и сборки на долгие годы.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
                <svg className="w-8 h-8 text-nuox-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              </div>
              <h3 className="text-xl font-bold mb-4">Экологичность</h3>
              <p className="text-sm text-gray-500">Используем только сертифицированное сырье класса E1.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
                <svg className="w-8 h-8 text-nuox-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" /></svg>
              </div>
              <h3 className="text-xl font-bold mb-4">Индивидуальность</h3>
              <p className="text-sm text-gray-500">Никаких шаблонов. Каждый проект уникален, как и его владелец.</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default About;

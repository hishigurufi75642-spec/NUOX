
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY || "";

export const getDesignAdvice = async (userPrompt: string) => {
  if (!API_KEY) return "API Key not configured.";

  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userPrompt,
      config: {
        systemInstruction: `Ты — эксперт-дизайнер интерьеров компании NUOX мебель. 
        Твоя задача — давать профессиональные советы по выбору мебели, материалов и планировке. 
        Акцентируй внимание на экологичности, функциональности и индивидуальном подходе NUOX. 
        Будь вежливым, профессиональным и вдохновляющим. Отвечай на русском языке. 
        Если пользователь спрашивает о конкретных типах мебели (кухни, спальни и т.д.), предлагай решения от NUOX.`,
        temperature: 0.7,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Извините, сейчас я не могу дать совет. Пожалуйста, попробуйте позже или закажите обратный звонок.";
  }
};

export const generateImage = async (prompt: string): Promise<string | null> => {
  if (!API_KEY) return null;

  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            text: `High-quality professional interior photography of ${prompt}. Modern minimalist style, natural lighting, high-end materials, eco-friendly furniture, 8k resolution, architectural digest style.`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "4:3",
        },
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Image Generation Error:", error);
    return null;
  }
};
